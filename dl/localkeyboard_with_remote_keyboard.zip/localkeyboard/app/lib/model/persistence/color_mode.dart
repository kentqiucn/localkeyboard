enum ColorMode {
  system, // dynamic colors
  localsend,
  oled,
  yaru,
}
