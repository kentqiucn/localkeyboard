#[derive(Clone, Debug)]
pub struct WebPageState;
